export interface Author {
  id: string;
  firstName: string;
  lastName: string;
  born: string;
}
