export interface Book {
  id: string;
  title: string;
  pages: number;
  authorId: string;
  genres: string[];
}
